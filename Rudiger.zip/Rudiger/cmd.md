# Подсказка по командной строке  

## Сменить директорию 
Windows
```sh
cd C:Path\to\folder

```
Linux\MacOs: 
```sh
cd Path/to/folder

```

## Очистить терминал Ctrl + L
Windows
```sh
cls

```
Linux/MacOs
```sh
clear

```

## Листинг файлов
Windows 
```sh
dir
```

Linux/MacOs
```sh
ls
```
## Создать директорию 

```sh
mkdir FolderName
```


